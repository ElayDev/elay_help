from setuptools import setup, find_packages

setup(
    name='elay_help',
    version='1.0.0.0',
    license='MIT',
    description='Un par de funciones pa facilitarme la via mami ya tu sae',
    author='ElayPY',
    packages=find_packages()
)