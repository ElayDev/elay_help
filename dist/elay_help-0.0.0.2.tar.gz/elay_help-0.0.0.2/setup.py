from setuptools import setup, find_packages

setup(
    name='elay_help',
    version='0.0.0.2',
    license='MIT',
    description='Un par de funciones pa facilitarme la via mami ya tu sae',
    author='ElayPY',
    packages=find_packages()
)